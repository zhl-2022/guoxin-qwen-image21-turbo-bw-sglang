from __future__ import annotations

from typing import TYPE_CHECKING

import torch
import triton
import triton.language as tl

from sglang.kernels.jit.utils import cache_once, load_jit, make_cpp_args
from sglang.kernels.kda_kernels import _cuda_source
from sglang.srt.utils.custom_op import register_custom_op

if TYPE_CHECKING:
    from tvm_ffi.module import Module


_SUPPORTED_DTYPES = (torch.float16, torch.bfloat16, torch.float32)
_BIT_EXACT_DTYPES = (torch.float16, torch.bfloat16)
_TRANSPOSE_TILE = 32
_MAX_GRID_DIM = 65535
_TRANSPOSED = -1  # route: the Triton kernel for the transposed-dense layout


@cache_once
def _jit_residual_gate_add_module(dtype: torch.dtype) -> Module:
    if dtype not in _SUPPORTED_DTYPES:
        raise RuntimeError(f"Unsupported residual_gate_add dtype: {dtype}")
    args = make_cpp_args(dtype)
    return load_jit(
        "diffusion_residual_gate_add",
        *args,
        cuda_files=[_cuda_source("diffusion/residual_gate_add.cuh")],
        cuda_wrappers=[
            (
                "residual_gate_add",
                f"residual_gate_add::ResidualGateAddKernel<{args}>::run",
            ),
        ],
    )


def _fake_impl(
    residual: torch.Tensor, update: torch.Tensor, gate: torch.Tensor, mode: int
) -> torch.Tensor:
    return torch.empty_strided(
        residual.shape,
        residual.stride(),
        dtype=residual.dtype,
        device=residual.device,
    )


def _residual_gate_add_cuda_impl(
    residual: torch.Tensor, update: torch.Tensor, gate: torch.Tensor, gate_mode: int
) -> torch.Tensor:
    out = torch.empty_like(residual)  # residual is contiguous on this path
    module = _jit_residual_gate_add_module(residual.dtype)
    if gate_mode == 3:
        # AdaLN unbind views have gaps between batch rows. Only copy the small
        # [B, 1, D] gate, never expand it across the token dimension.
        gate = gate.contiguous()
    module.residual_gate_add(
        out.view(-1),
        residual.view(-1),
        update.view(-1),
        gate.view(-1),
        residual.shape[-1],
        gate_mode,
    )
    return out


@triton.jit
def _round16_f32(x, IS_BF16: tl.constexpr):
    if IS_BF16:
        bits = tl.inline_asm_elementwise(
            "cvt.rn.bf16.f32 $0, $1;", "=h,r", [x], dtype=tl.int16, is_pure=True, pack=1
        )
        return bits.to(tl.bfloat16, bitcast=True).to(tl.float32)
    else:
        bits = tl.inline_asm_elementwise(
            "cvt.rn.f16.f32 $0, $1;", "=h,r", [x], dtype=tl.int16, is_pure=True, pack=1
        )
        return bits.to(tl.float16, bitcast=True).to(tl.float32)


@triton.jit
def _rga_transposed(
    out,
    res,
    upd,
    gate,
    tokens,
    hid: tl.constexpr,
    IS_BF16: tl.constexpr,
    IS_16: tl.constexpr,
    TILE: tl.constexpr,
):
    # residual/out have logical [batch, tokens, hid] with physical strides (T*H, 1, T);
    # update is contiguous. out[b,t,h] = res + upd * gate[h].
    # h-major tile indexing ([TILE_h, TILE_t]) makes the residual/output access
    # coalesced along the physical stride-1 token dim; update (read once) takes
    # the strided pattern instead. Measured faster than the t-major layout.
    pid_t = tl.program_id(0).to(tl.int64)
    pid_h = tl.program_id(1).to(tl.int64)
    pid_b = tl.program_id(2).to(tl.int64)
    t = pid_t * TILE + tl.arange(0, TILE).to(tl.int64)
    h = pid_h * TILE + tl.arange(0, TILE).to(tl.int64)
    mt = t < tokens
    mh = h < hid
    gv = tl.load(gate + h, mask=mh, other=0.0)
    base = pid_b * tokens * hid
    m2 = mh[:, None] & mt[None, :]
    roffs = h[:, None] * tokens + t[None, :]
    rv = tl.load(res + base + roffs, mask=m2, other=0.0)
    uv = tl.load(upd + base + t[None, :] * hid + h[:, None], mask=m2, other=0.0)
    if IS_16:
        p32 = uv.to(tl.float32) * gv[:, None].to(tl.float32)
        pf = _round16_f32(p32, IS_BF16)
        o32 = rv.to(tl.float32) + pf
        if IS_BF16:
            bits = tl.inline_asm_elementwise(
                "cvt.rn.bf16.f32 $0, $1;",
                "=h,r",
                [o32],
                dtype=tl.int16,
                is_pure=True,
                pack=1,
            )
            tl.store(out + base + roffs, bits.to(tl.bfloat16, bitcast=True), mask=m2)
        else:
            bits = tl.inline_asm_elementwise(
                "cvt.rn.f16.f32 $0, $1;",
                "=h,r",
                [o32],
                dtype=tl.int16,
                is_pure=True,
                pack=1,
            )
            tl.store(out + base + roffs, bits.to(tl.float16, bitcast=True), mask=m2)
    else:
        tl.store(out + base + roffs, rv + uv * gv[:, None], mask=m2)


def _residual_gate_add_transposed(residual, update, gate):
    out = torch.empty_strided(
        residual.shape, residual.stride(), dtype=residual.dtype, device=residual.device
    )
    batch, tokens, hidden = residual.shape
    if residual.numel() <= 65536:
        tile, warps = 16, 4
    elif residual.numel() >= 1 << 20:
        tile, warps = 64, 8
    else:
        tile, warps = 32, 8
    grid = (triton.cdiv(tokens, tile), triton.cdiv(hidden, tile), batch)
    _rga_transposed[grid](
        out,
        residual,
        update,
        gate,
        tokens,
        hidden,
        residual.dtype == torch.bfloat16,
        residual.dtype in (torch.float16, torch.bfloat16),
        TILE=tile,
        num_warps=warps,
    )
    return out


@register_custom_op(
    op_name="diffusion_residual_gate_add",
    mutates_args=[],
    fake_impl=_fake_impl,
)
def _residual_gate_add_custom_op(
    residual: torch.Tensor, update: torch.Tensor, gate: torch.Tensor, mode: int
) -> torch.Tensor:
    if residual.get_device() == torch.cuda.current_device():
        return _launch(residual, update, gate, mode)
    with torch.cuda.device(residual.device):
        return _launch(residual, update, gate, mode)


def _launch(
    residual: torch.Tensor, update: torch.Tensor, gate: torch.Tensor, mode: int
) -> torch.Tensor:
    if mode == _TRANSPOSED:
        return _residual_gate_add_transposed(residual, update, gate)
    return _residual_gate_add_cuda_impl(residual, update, gate, mode)


def _route(residual: torch.Tensor, update: torch.Tensor, gate: torch.Tensor):
    """The kernel for these operands: a gate mode, _TRANSPOSED, or None if unsupported."""
    if not (
        torch.version.hip is None
        and residual.dtype in _SUPPORTED_DTYPES
        and residual.dtype == update.dtype == gate.dtype
        and residual.is_cuda
        and residual.device == update.device == gate.device
        and residual.dim() >= 2
        and residual.numel() > 0
        and update.shape == residual.shape
    ):
        return None
    # Take the Triton path only for the transposed-dense layout it was
    # benchmarked on. For the contiguous layouts every other diffusion model
    # uses, the existing JIT CUDA kernel is faster at every measured shape.
    if _is_transposed_dense_residual(residual, update, gate):
        return _TRANSPOSED
    if not (residual.is_contiguous() and update.is_contiguous()):
        return None
    mode = _gate_mode(residual, gate)
    if mode == 2 and not _is_per_token_gate(residual, gate):
        return None
    if mode != 3 and not gate.is_contiguous():
        return None
    return mode


def _gate_mode(residual: torch.Tensor, gate: torch.Tensor) -> int:
    """0 = full, 1 = shared row, 2 = per-token, 3 = one row per batch."""
    if gate.shape == residual.shape:
        return 0
    if _is_row_broadcast_gate(residual, gate):
        return 1
    if _is_batched_row_gate(residual, gate):
        return 3
    return 2


def _is_row_broadcast_gate(residual: torch.Tensor, gate: torch.Tensor) -> bool:
    if gate.dim() != residual.dim() or gate.shape[-1] != residual.shape[-1]:
        return False
    return all(size == 1 for size in gate.shape[:-1])


def _is_per_token_gate(residual: torch.Tensor, gate: torch.Tensor) -> bool:
    """Gate holds one scalar per token (row), broadcast along the hidden dim."""
    return (
        gate.dim() == residual.dim()
        and gate.shape[-1] == 1
        and gate.shape[:-1] == residual.shape[:-1]
    )


def _is_batched_row_gate(residual: torch.Tensor, gate: torch.Tensor) -> bool:
    return (
        residual.dim() == 3
        and 1 < residual.shape[0] <= _MAX_GRID_DIM
        and gate.shape == (residual.shape[0], 1, residual.shape[-1])
    )


def _is_transposed_dense_residual(
    residual: torch.Tensor, update: torch.Tensor, gate: torch.Tensor
) -> bool:
    if residual.dim() != 3 or gate.shape != (1, 1, residual.shape[-1]):
        return False
    batch, tokens, hidden_size = residual.shape
    return (
        residual.stride() == (tokens * hidden_size, 1, tokens)
        and batch <= _MAX_GRID_DIM
        and (tokens + _TRANSPOSE_TILE - 1) // _TRANSPOSE_TILE <= _MAX_GRID_DIM
        and (hidden_size + _TRANSPOSE_TILE - 1) // _TRANSPOSE_TILE <= _MAX_GRID_DIM
        and update.is_contiguous()
        and gate.is_contiguous()
    )


def can_use_residual_gate_add_cuda(
    residual: torch.Tensor, update: torch.Tensor, gate: torch.Tensor
) -> bool:
    return _route(residual, update, gate) is not None


def residual_gate_add_cuda(
    residual: torch.Tensor, update: torch.Tensor, gate: torch.Tensor
) -> torch.Tensor:
    mode = _route(residual, update, gate)
    if mode is None:
        raise RuntimeError("unsupported input for residual_gate_add CUDA")
    return _residual_gate_add_custom_op(residual, update, gate, mode)


def residual_gate_add(
    residual: torch.Tensor, update: torch.Tensor, gate: torch.Tensor
) -> torch.Tensor:
    """Use the bit-exact fast path for supported layouts, otherwise eager."""
    if residual.dtype in _BIT_EXACT_DTYPES:
        mode = _route(residual, update, gate)
        if mode is not None:
            return _residual_gate_add_custom_op(residual, update, gate, mode)
    return residual + update * gate


__all__ = [
    "can_use_residual_gate_add_cuda",
    "residual_gate_add",
    "residual_gate_add_cuda",
]
