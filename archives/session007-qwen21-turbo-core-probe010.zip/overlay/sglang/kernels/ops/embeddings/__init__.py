"""Embedding kernels."""

from sglang.kernels.registry import register_kernel
from sglang.kernels.spec import CUDA_ONLY, KernelBackend, KernelSpec

register_kernel(
    KernelSpec(
        op="embeddings.vocab_parallel_embedding",
        backend=KernelBackend.TRITON,
        target=(
            "sglang.kernels.ops.embeddings.vocab_parallel_embedding:"
            "vocab_parallel_embedding"
        ),
    )
)

register_kernel(
    KernelSpec(
        op="embeddings.engram_gather",
        backend=KernelBackend.TRITON,
        target="sglang.kernels.ops.embeddings.engram_gather:engram_gather",
    )
)

register_kernel(
    KernelSpec(
        op="embeddings.engram_gather_peer",
        backend=KernelBackend.TRITON,
        target="sglang.kernels.ops.embeddings.engram_gather:engram_gather_peer",
    )
)

register_kernel(
    KernelSpec(
        op="embeddings.engram_hash_ids",
        backend=KernelBackend.TRITON,
        target="sglang.kernels.ops.embeddings.engram_hash:engram_hash_ids",
    )
)

register_kernel(
    KernelSpec(
        op="embeddings.engram_hash_ids_and_commit",
        backend=KernelBackend.TRITON,
        target="sglang.kernels.ops.embeddings.engram_hash:engram_hash_ids_and_commit",
    )
)

register_kernel(
    KernelSpec(
        op="embeddings.engram_commit_history",
        backend=KernelBackend.TRITON,
        target="sglang.kernels.ops.embeddings.engram_hash:engram_commit_history",
    )
)

register_kernel(
    KernelSpec(
        op="embeddings.fused_engram_gate",
        backend=KernelBackend.TRITON,
        target="sglang.kernels.ops.embeddings.engram_gate:fused_engram_gate",
    )
)

__all__ = []


# Public entry points inventoried by logical operator group (RFC #29630).
register_kernel(
    KernelSpec(
        op="embeddings.fused_qwen4_ngram_hash",
        backend=KernelBackend.TRITON,
        target="sglang.kernels.ops.embeddings.qwen4_ngram:fused_qwen4_ngram_hash",
        capabilities=CUDA_ONLY,
    )
)
