"""Diffusion-specific routing kernels."""
