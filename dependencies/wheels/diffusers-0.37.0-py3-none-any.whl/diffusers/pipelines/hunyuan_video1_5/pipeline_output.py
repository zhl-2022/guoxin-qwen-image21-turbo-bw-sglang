from dataclasses import dataclass

import torch

from diffusers.utils import BaseOutput


@dataclass
class HunyuanVideo15PipelineOutput(BaseOutput):
    r"""
    Output class for HunyuanVideo1.5 pipelines.

    Args:
        frames (`torch.Tensor`, `np.ndarray`, or list[list[PIL.Image.Image]]):
            List of video outputs - It can be a nested list of length `batch_size,` with each sub-list containing
            denoised PIL image sequences of length `num_frames.` It can also be a NumPy array or Torch tensor of shape
            `(batch_size, num_frames, channels, height, width)`.
    """

    frames: torch.Tensor
